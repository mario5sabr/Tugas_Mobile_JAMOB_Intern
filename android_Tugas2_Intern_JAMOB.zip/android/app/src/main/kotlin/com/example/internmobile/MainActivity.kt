package com.example.internmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
