import 'package:flutter/material.dart';

const xBackGroundColor = Color(0xFFFFBD73);
const xPrimaryColor = Color.fromARGB(253, 233, 140, 0);
